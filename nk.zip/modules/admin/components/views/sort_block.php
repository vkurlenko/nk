<div class="sort-widget">
    <input type="text" size="5" value="<?=$data->sort?>" class="sort-widget-input">
    <a href="/admin/persons/setsort" class="btn set_sort" data-id="<?=$data->id?>" data-model="<?=$model_name?>">
        <span class="glyphicon glyphicon-floppy-disk"></span>
    </a>
</div>