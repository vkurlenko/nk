<section id="slider1">
    <div class="slider-main">

        <div class="item active">
            <img src="/web/images/slide1.jpg" alt="">
            <div class="carousel-caption-nk">
                Победитель проекта: Светлана
            </div>
        </div>

        <div class="item">
            <img src="/web/images/slide2.jpg" alt="">
            <div class="carousel-caption-nk">
                Победитель проекта: Ирина
            </div>
        </div>

    </div>
    <div class="laces"></div>
</section>