<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 12.06.2018
 * Time: 19:51
 */
function debug($arr)
{
    echo '<pre>' . print_r($arr, true) . '</pre>';
}